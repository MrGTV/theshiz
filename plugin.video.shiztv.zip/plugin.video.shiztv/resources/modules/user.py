import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLnNoaXp0dg==')

name = b.b64decode('U0hJWiBUVg==')

host = b.b64decode('aHR0cDovL3NoaXp0di54eXo=')

port = b.b64decode('ODA=')